import React from 'react';
import Home from './Home.js';

function App() {
  return (
    <div className="App">
      <Home />
    </div>
  );
}

export default App;
